#!/usr/bin/env python
# subscribe to /cmd_vel, /joint_states, /imu
# pulish to /odom, transforms on /odom, wheels command
import math
import rospy
import tf
import numpy as np
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
from geometry_msgs.msg import Point, Pose, Quaternion, Twist, Vector3
from sensor_msgs.msg import Imu, JointState

class Mecanum_Ctrl():
    def __init__(self):
        # physical parameters
        self.base_lx = 0.25
        self.base_ly = 0.25
        self.lx_ly = self.base_lx + self.base_ly
        self.wheel_radii = 0.04
        self.wheel_posn = [[0.2, 0.056, -0.236], [-0.2, 0.056, -0.34], [-0.2, 0.056, 0.236], [0.2, 0.056, 0.34]]
        self.wheel_orient = [[1.57, 0, 0], [-1.57, 0, 0], [-1.57, 0, 0], [1.57, 0, 0]]
        self.wheel_joint_names = ["" for i in range(4)]
        self.wheel_frames = ['left_rim_one_link', 'right_rim_two_link', 'left_rim_three_link', 'right_rim_four_link']
            # wrt GND frame
        self.curr_x_pos = 0
        self.curr_y_pos = 0
        self.curr_theta = 0
        self.motor_rotn = [0.0 for i in range(4)]
        self.motor_vel = np.array([[0.0] for i in range(4)])
        # playing with sensor data
        self.last_time = rospy.Time.now()
        self.imu_offset = 0
        self.bool_imu_offset = 1
        self.motor_theta_offset = [0.0 for i in range(4)]
        # self.motor_vel_offset = [0.0 for i in range(4)]
        self.bool_motor_offset = 1
        # topics
        self.cmd_topic = '/cmd_vel'
        self.odom_topic = '/odom'
        self.imu_topic = '/imu'
        self.odom_transform_topic = '/odom'
        self.odom_frame = 'odom'
        self.robot_base_frame = 'base_footprint'
        
        # kinematics
        self.v_to_w_mat = 1/self.wheel_radii * np.array([[1, 1, self.lx_ly],
                      [1, -1, self.lx_ly],
                      [1, 1, -self.lx_ly],
                      [1, -1, -self.lx_ly]])
        # to match the rotation direction
        self.v_to_w_mat[1] *= -1
        self.v_to_w_mat[2] *= -1
        # self.w_to_v_mat = 1/4*self.wheel_radii * np.array([[1, 1, 1, 1],
        #                       [1, -1, 1, -1],
        #                       [1/self.lx_ly, 1/self.lx_ly, -1/self.lx_ly, -1/self.lx_ly]])
        # to match the rotation direction
        # self.w_to_v_mat = 1/4*self.wheel_radii * np.array([[1, -1, -1, 1],
        #                       [1, 1, -1, -1],
        #                       [1/self.lx_ly, -1/self.lx_ly, 1/self.lx_ly, -1/self.lx_ly]])
        # to match the joint order in joint states--------->
        self.w_to_v_mat = 1/4*self.wheel_radii * np.array([[1, -1, 1, -1],
                                                            [1, -1, -1, 1],
                                                            [1/self.lx_ly, 1/self.lx_ly, -1/self.lx_ly, -1/self.lx_ly]])
        
        # subs and pubs
        self.cmd_subs = rospy.Subscriber(self.cmd_topic, Twist, self.callback_cmd)
        self.imu_subs = rospy.Subscriber(self.imu_topic, Imu, self.callback_imu)
        self.joint_state_subs = rospy.Subscriber('/mecanum/joint_states', JointState, self.callback_joint_states)
        
        # tfs 
        self.base_br = tf.TransformBroadcaster()
        self.wheel_br = [tf.TransformBroadcaster() for i in range(4)]
        
        self.odom_pub = rospy.Publisher(self.odom_topic, Odometry, queue_size=10)
        self.pub1 = rospy.Publisher(
        '/mecanum/one_joint_velocity_controller/command', Float64, queue_size=1)
        self.pub2 = rospy.Publisher(
            '/mecanum/two_joint_velocity_controller/command', Float64, queue_size=1)
        self.pub3 = rospy.Publisher(
            '/mecanum/three_joint_velocity_controller/command', Float64, queue_size=1)
        self.pub4 = rospy.Publisher(
            '/mecanum/four_joint_velocity_controller/command', Float64, queue_size=1)
        self.wheel_cmd_arr = [self.pub1, self.pub2, self.pub3, self.pub4]

        
    def callback_cmd(self, msg):
        vx = msg.linear.x
        vy = msg.linear.y
        _w = msg.angular.z
        vrr = np.array([[vx], [vy], [_w]])
        prr = np.matmul(self.v_to_w_mat, vrr)
        for i in range(4):
            self.wheel_cmd_arr[i].publish(prr[i][0])
            
    def callback_imu(self, msg):
        orientation = msg.orientation
        w, x, y, z = orientation.w, orientation.x, orientation.y, orientation.z 
        # radians : math.degrees(radian)
        yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y**2 + z**2))
        pitch = math.asin(2 * (w * y - x * z))
        roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x**2 + y**2))
        if self.bool_imu_offset == 1:
            self.imu_offset = yaw
            self.bool_imu_offset = 0
        self.curr_theta = yaw - self.imu_offset

        
    def callback_joint_states(self, msg):
        position = msg.position
        velocity = msg.velocity
        if (self.bool_motor_offset == 1):
            self.wheel_joint_names = msg.name
            self.last_time = rospy.Time.now()
            for i in range(4):
                self.motor_theta_offset[i] = position[i]
            # for i in range(4):
            #     self.motor_vel_offset[i] = velocity[i]
            self.bool_motor_offset = 0
            
        dt =  (rospy.Time.now() - self.last_time).to_sec()
        self.last_time = rospy.Time.now()
        for i in range(4):
            self.motor_rotn[i] = position[i] - self.motor_theta_offset[i]
            self.wheel_orient[i][1] = self.motor_rotn[i]
        for i in range(4):
            self.motor_vel[i][0] = velocity[i]
        vel_wrt_bot = np.matmul(self.w_to_v_mat, self.motor_vel)
        _vx = vel_wrt_bot[0][0]
        _vy = vel_wrt_bot[1][0]
        _dx = (_vx*math.cos(self.curr_theta) - _vy*math.sin(self.curr_theta))*dt
        _dy = (_vx*math.sin(self.curr_theta) + _vy*math.cos(self.curr_theta))*dt
        _th = vel_wrt_bot[2][0]*dt
        self.curr_x_pos+=_dx
        self.curr_y_pos+=_dy
        self.curr_theta+=_th
        
        rospy.loginfo('POSE: %f, %f, %f:', self.curr_x_pos, self.curr_y_pos, self.curr_theta)
        
        current_time = rospy.Time.now()
        odom = Odometry()
        odom.header.stamp = current_time
        odom.header.frame_id = 'odom'
        odom.child_frame_id = self.robot_base_frame
        odom.pose.pose.position.x = self.curr_x_pos
        odom.pose.pose.position.y = self.curr_y_pos
        odom.pose.pose.position.z = 0.0
        quaternion = tf.transformations.quaternion_from_euler(0, 0, self.curr_theta)
        odom.pose.pose.orientation.x = quaternion[0]
        odom.pose.pose.orientation.y = quaternion[1]
        odom.pose.pose.orientation.z = quaternion[2]
        odom.pose.pose.orientation.w = quaternion[3]
        self.odom_pub.publish(odom)
        self.publish_base_tf()
        # self.publish_wheel_tf()
        
    def publish_base_tf(self):
        self.base_br.sendTransform((self.curr_x_pos, self.curr_y_pos, 0),
                         tf.transformations.quaternion_from_euler(0, 0, self.curr_theta),
                         rospy.Time.now(),
                         self.robot_base_frame,
                         self.odom_frame)
    # def publish_wheel_tf(self):
    #     for i in range(4):
    #         self.wheel_br[i].sendTransform(tuple(self.wheel_posn[i]),
    #                      tf.transformations.quaternion_from_euler(self.wheel_orient[i][0], self.wheel_orient[i][1], self.wheel_orient[i][2]),
    #                      rospy.Time.now(),
    #                      self.robot_base_frame,
    #                      self.wheel_frames[i])
        
if __name__ == '__main__':
    rospy.init_node('Mecanum_Ctrl')
    rospy.loginfo("Node started")
    mecanum_ctrl = Mecanum_Ctrl()
    rospy.spin()